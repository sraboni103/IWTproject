<style type="text/css">
 






html{
    scroll-behavior:smooth;
}


    *{
        background-color: ass;
        margin:0%;
        padding: 0%;
        box-sizing:border-box;
        font-family: 'Mulish', sans-serif;
    }

    .nav_style{
      
      background-color: #a29bfe!important;

    }

.nav_style a{
    color:white;
}

/* main header start */

.main_header{
    height: 450;
    width: 100%;
}

.rightside h1{
    font-size:5rem;
}

.corona_rot{
    animation:gocorona 3s linear infinite;
}

@keyframes gocorona {
    0% {transform: rotate(0);}
    100% {transform: rotate(360deg);}
    
}


/* corona update  */

.corona_update{
    margin: 0 0 30px 0;
}

.corona_update h3{
    color: #ff7675;
}
.corona_update h1{font-size: 2rem; text-align:center; }

}


/* about section */

.sub_section{
    background-color:lightgray;
}

/* top-cursor */



/* footer */
.footer_style{

background-color: #a29bfe;

}

.footer_style p{
  margin-bottom: 0!important;

}





</style>